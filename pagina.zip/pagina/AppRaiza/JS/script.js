

  const form = document.getElementById('loginForm');
  const emailInput = document.getElementById('email');
  const passwordInput = document.getElementById('password');
  const emailError = document.getElementById('emailError');
  const passwordError = document.getElementById('passwordError');
  const togglePw = document.getElementById('togglePw');
  const submitBtn = document.getElementById('submitBtn');
  const statusMsg = document.getElementById('statusMsg');

  // Cuenta de demostración válida, solo para probar el flujo en esta página.
  const DEMO_EMAIL = 'usuario@correo.com';
  const DEMO_PASSWORD = 'clave1234';

  function isValidEmail(value){
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
  }

  function setFieldState(input, errorEl, message){
    if (message){
      input.classList.add('invalid');
      errorEl.textContent = message;
    } else {
      input.classList.remove('invalid');
      errorEl.textContent = '';
    }
  }

  togglePw.addEventListener('click', () => {
    const isHidden = passwordInput.type === 'password';
    passwordInput.type = isHidden ? 'text' : 'password';
    togglePw.textContent = isHidden ? 'Ocultar' : 'Ver';
  });

  emailInput.addEventListener('input', () => setFieldState(emailInput, emailError, ''));
  passwordInput.addEventListener('input', () => setFieldState(passwordInput, passwordError, ''));

  form.addEventListener('submit', (event) => {
    event.preventDefault();
    statusMsg.textContent = '';
    statusMsg.className = 'status';

    let hasError = false;

    if (!emailInput.value.trim()){
      setFieldState(emailInput, emailError, 'Ingresa tu correo electrónico.');
      hasError = true;
    } else if (!isValidEmail(emailInput.value.trim())){
      setFieldState(emailInput, emailError, 'Ingresa un correo válido.');
      hasError = true;
    } else {
      setFieldState(emailInput, emailError, '');
    }

    if (!passwordInput.value){
      setFieldState(passwordInput, passwordError, 'Ingresa tu contraseña.');
      hasError = true;
    } else if (passwordInput.value.length < 8){
      setFieldState(passwordInput, passwordError, 'Debe tener al menos 8 caracteres.');
      hasError = true;
    } else {
      setFieldState(passwordInput, passwordError, '');
    }

    if (hasError) return;

    submitBtn.disabled = true;
    submitBtn.textContent = 'Verificando...';

    setTimeout(() => {
      const match = emailInput.value.trim() === DEMO_EMAIL && passwordInput.value === DEMO_PASSWORD;

      if (match){
        statusMsg.textContent = 'Sesión iniciada correctamente.';
        statusMsg.classList.add('success');
      } else {
        statusMsg.textContent = 'Correo o contraseña incorrectos.';
        statusMsg.classList.add('fail');
      }

      submitBtn.disabled = false;
      submitBtn.textContent = 'Iniciar sesión';
    }, 700);
  });
   
